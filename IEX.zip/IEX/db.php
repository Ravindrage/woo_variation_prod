<?php
	$hostname = "localhost";
	$db = "importex";
	$password = "";
	$user = "root";
	$mysqli = new mysqli($hostname, $user, $password, $db);
?>