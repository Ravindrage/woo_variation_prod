<?php  

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);



if(isset($_POST['submit'])) {
     if(isset($_FILES['uploadFile']['name']) && $_FILES['uploadFile']['name'] != "") {
        $allowedExtensions = array("xls","xlsx");
        $ext = pathinfo($_FILES['uploadFile']['name'], PATHINFO_EXTENSION);
		
        if(in_array($ext, $allowedExtensions)) {
				// Uploaded file
               $file = "uploads/".$_FILES['uploadFile']['name'];
               $isUploaded = copy($_FILES['uploadFile']['tmp_name'], $file);
			   // check uploaded file
               if($isUploaded) {
					// Include PHPExcel files and database configuration file
                    include("db.php");
					require_once __DIR__ . '/vendor/autoload.php';
                    include(__DIR__ .'/vendor/phpoffice/phpexcel/Classes/PHPExcel/IOFactory.php');
                    try {
                        // load uploaded file
                        $objPHPExcel = PHPExcel_IOFactory::load($file);
                    } catch (Exception $e) {
                         die('Error loading file "' . pathinfo($file, PATHINFO_BASENAME). '": ' . $e->getMessage());
                    }
                    
                    // Specify the excel sheet index
                    $sheet = $objPHPExcel->getSheet(0);
                    $total_rows = $sheet->getHighestRow();
					$highestColumn      = $sheet->getHighestColumn();	
					$highestColumnIndex = PHPExcel_Cell::columnIndexFromString($highestColumn);		
					
					//	loop over the rows
					for ($row = 1; $row <= $total_rows; ++ $row) {
						for ($col = 0; $col < $highestColumnIndex; ++ $col) {
							$cell = $sheet->getCellByColumnAndRow($col, $row);
							$val = $cell->getValue();
							$records[$row][$col] = $val;
						}
					}
					$html="<table border='1'>";
					$html.="<tr><th>Roll No</th>";
					$html.="<th>Name</th><th>Age</th>";
					$html.="<th>Program</th></tr>";
					
					
					//$query = "SELECT MAX(id) FROM table1";
					//$max = $mysqli->query($query);
					//print_r($max);
					//$row = mysqli_result($max);
					//print_r($row);
					
					$i= 0;
					$temp_product =  '';  $attribute1value=''; $attribute2value='';
					$allid = array( ); 
					foreach($records as $row){
						$i++; 
						// HTML content to render on webpage
						$html.="<tr>";
						$code = isset($row[0]) ? $row[0] : '';
						$brand = isset($row[1]) ? $row[1] : '';
						$Name = $productName = isset($row[2]) ? $row[2] : '';
						$typeofSeed = isset($row[3]) ? $row[3] : '';
						$description = isset($row[4]) ? $row[4] : '';
						$mrp = isset($row[5]) ? $row[5] : '';
						$rate = isset($row[6]) ? $row[6] : '';
						$quantity = isset($row[7]) ? $row[7] : '';
						$packSize = isset($row[8]) ? $row[8] : '';
						$packWeight = isset($row[9]) ? $row[9] : '';
						$keyPoint1 = isset($row[10]) ? $row[10] : '';
						$keyPoint2 = isset($row[11]) ? $row[11] : '';
						$keyPoint3 = isset($row[12]) ? $row[12] : '';
						$keyPoint4 = isset($row[13]) ? $row[13] : '';
						
						
						$description = str_replace("'"," ",$description);
						
						$keyPoint1 = str_replace("'"," ",$keyPoint1);
						$keyPoint2 = str_replace("'"," ",$keyPoint2);
						$keyPoint3 = str_replace("'"," ",$keyPoint3);
						$keyPoint4 = str_replace("'"," ",$keyPoint4);
						
									
						
						//////////////// INSERT  DATA INTO EXCEL TABLE START /////////////////////////////
						$query = "INSERT INTO excel (code,brandName,productName,typeofSeed,description,mrp,rate,quantity,packSize,packWeight,keyPoint1,keyPoint2,keyPoint3,keyPoint4) 
								values('".$code."','".$brand."','".$productName."','".$typeofSeed."','".$description."','".$mrp."','".$rate."','".$quantity."','".$packSize."','".$packWeight."','".$keyPoint1."','".$keyPoint2."','".$keyPoint3."','".$keyPoint4."')";
                        
						$mysqli->query($query);	
						//////////////// INSERT  DATA INTO EXCEL TABLE COMPLETE  ////////

						
						/////////////// PARANT PRODUCT FUNCTIONALITY START///////////////////			
						$attribute1value = $attribute1value.','.$quantity ; 
						$attribute2value = $attribute2value.','.$packSize ; 
						
						
						if(($productName==''))
						{ 
							echo 'Hello';
							$code=$tempcode  ;
							$brand= $tempbrand ;
							$productName= $tempName  ;
							$typeofSeed= $temptypeofSeed  ;
							$description=$tempdescription  ;
							$mrp= $tempmrp  ;
							$rate = $temprate  ;
							$quantity= $tempquantity  ;
							$packSize =$temppackSize  ;
							$packWeight= $temppackWeight  ;
							$keyPoint1  = $tempkeyPoint1 ;
							$keyPoint2= $tempkeyPoint2   ;
							$keyPoint3 = $tempkeyPoint3  ;
							$keyPoint4  = $tempkeyPoint4 ;
							$sku = str_ireplace(" ","_",$productName);
							
							echo $query2 = "INSERT INTO excel1 (id,Type,SKU,Name,Published,Visibility_in_catalog,Short_description,Description,`In stock?`,Weight,Length,Width,Height,Sale_price,Regular_price,Categories,Images,Download_limit,Parent,`Attribute 1 name`,`Attribute 1 value`,`Attribute 1 visible`,`Attribute 1 global`,`Attribute 2 name`,`Attribute 2 value`,`Attribute 2 visible`,`Attribute 2 global`) 
						    values('','variable','".$sku."','".$productName."','1','visible','','".$description."','1','','','','','".$rate."','".$mrp."','".$typeofSeed."','','','','QUANTITY','".$attribute1value."','1','1','Pack weight','".$attribute2value."','1','1')";
							$mysqli->query($query2);	
							
							$comma_sep_ids = implode(',',$allid) ; 
							
							echo $update = "Update excel1 set Parent='".$sku."' where id in (".$comma_sep_ids.")";
							$mysqli->query($update);	
							$allid  = array();

							//exit;
							
						}
												
									$sku = str_ireplace(" ","_",$productName);			
						///////////////PARANT PRODUCT FUNCTIONALITY COMPLETE/////////////////////////////
						
						

                        if($i>1) {
							
						$attribute1value = $attribute1value.','.$quantity ; 
						$attribute2value = $attribute2value.','.$packSize ; 
												
						echo $query2 = "INSERT INTO excel1 (id,Type,SKU,Name,Published,Visibility_in_catalog,Short_description,Description,`In stock?`,Weight,Length,Width,Height,Sale_price,Regular_price,Categories,Images,Download_limit,Parent,`Attribute 1 name`,`Attribute 1 value`,`Attribute 1 visible`,`Attribute 1 global`,`Attribute 2 name`,`Attribute 2 value`,`Attribute 2 visible`,`Attribute 2 global`) 
						    values('','variation','".$sku."','".$productName."','1','visible','','".$description."','1','','','','','".$rate."','".$mrp."','".$typeofSeed."','','','','QUANTITY','".$attribute1value."','1','1','Pack weight','".$attribute2value."','1','1')";
							$mysqli->query($query2);

						$last_id = $mysqli->insert_id;	
						array_push($allid,$last_id);

                      	echo '<br>'	;
						}
						
						if($i>49)
						{
							exit;
						}
						
												
						
						$tempcode = $code ;
						$tempbrand = $brand ;
						$tempName  = $productName ;
						$temptypeofSeed = $typeofSeed ;
						$tempdescription = $description ;
						$tempmrp =  $mrp ;
						$temprate = $rate ;
						$tempquantity = $quantity ;
						$temppackSize = $packSize ;
						$temppackWeight = $packWeight ;
						$tempkeyPoint1 = $keyPoint1 ;
						$tempkeyPoint2  = $keyPoint2 ;
						$tempkeyPoint3 = $keyPoint3 ;
						$tempkeyPoint4 = $keyPoint4 ;
										
											}
					$html.="</table>";
					
					echo "<br/>Data inserted in Database";
					
					
					$queryselect = "select * from importtable";
					$result = $mysqli->query($queryselect);
                
					$result -> free_result();					
				
                    unlink($file);
                } else {
                    echo '<span class="msg">File not uploaded!</span>';
                }
        } else {
            echo '<span class="msg">Please upload excel sheet.</span>';
        }
    } else {
        echo '<span class="msg">Please upload excel file.</span>';
    }
}



function parent_product()
{
	$query2 = "INSERT INTO excel1 (id,Type,SKU,Name,Published,Visibility_in_catalog,Short_description,Description,Weight,Length,Width,Height,Sale_price,Regular_price,Categories,Images,Download_limit,Parent,Attribute_1_name,Attribute_1_value,Attribute_2_name,Attribute_2_value) 
						values('','variation','','".$productName."','','','','".$description."','','','','','".$rate."','".$mrp."','".$typeofSeed."','','','','QUANTITY','".$quantity."','Pack weight','".$packSize."')";

	$mainquantity = $quantity.',' ;
	$mainpacksize = $packSize.',' ;

	$mysqli->query($query2);	
	echo '<br>'	;
}

?>